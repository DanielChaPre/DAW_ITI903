<?php
//------------------
 function Titulo($titulo){
    echo "<br> <strong>$titulo</strong><br>";
 }

 function salto(){
     echo "<br><hr><br>";
 }