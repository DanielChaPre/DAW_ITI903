<a href="1P_AI10.php">Inicio </a> <br><br>

<?php 

/*$method = $_SERVER["REQUEST_METHOD"];
echo $method;
if($method != "POST"){
// echo "<img src=/>";
echo "Metodo no permitido";
 http_response_code(405);
 exit;
}*/

/*if(isset($_GET["nombre"])){
    echo $_GET["nombre"];
}*/

echo var_dump($_POST);

?>




