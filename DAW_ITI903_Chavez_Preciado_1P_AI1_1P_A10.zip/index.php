<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
</head>
<body>
    <a href = "1P_AI1.php">1P_AI1 variables </a> <br><br>
    <a href = "1P_AI2.php">1P_AI2 Comparaciones </a> <br><br>
    <a href = "1P_AI3.php">1P_AI3  Edad</a> <br><br>
    <a href = "1P_AI4.php">1P_AI4  Ciclos</a> <br><br>
    <a href = "1P_AI5.php">1P_AI5  Ejercicio de ciclos</a> <br><br>
    <a href = "1P_AI6.php">1P_AI6 Funciones </a> <br><br>
    <a href = "1P_AI7.php">1P_AI7 include e include_once </a> <br><br>
    <a href = "1P_AI8.php">1P_AI8 POO </a> <br><br>
    <a href = "1P_AI9.php">1P_AI9 BD, CRUD </a> <br><br>
    <a href = "1P_AI10.php">1P_AI10. Estructura y HTTP</a> <br><br>
    <a href = "1P_AI11/index.php">1P_AI11. Calculadora</a> <br><br>
    <a href = "Practica1Examen.php">Examen</a> <br><br>

</body>
</html>