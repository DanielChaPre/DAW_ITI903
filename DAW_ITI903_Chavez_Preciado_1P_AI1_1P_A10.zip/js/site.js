function saludar(){
    alert("Hola desde pagina 2");
}