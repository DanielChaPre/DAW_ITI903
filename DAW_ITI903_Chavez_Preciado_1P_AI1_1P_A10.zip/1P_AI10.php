
<?php include('layout/header.php')?>

<a href="1P_AI10_2.php">ir a Página 2</a> <br><br>

<form action="1P_AI10_peticiones.php" method="post">
<input type="text" name="id"><br>
<button name="" type="button" >Producto 1</button>
<button name="boton2" value="btn1">Producto 2</button>

</form>
<!---
<form action="1P_AI10_peticiones.php" method="POST">
<input type="text" name="nombre"><br>
<button>Producto 2</button>

<a href="1P_AI10_peticiones.php?id=1">Producto 1</a>
<a href="1P_AI10_peticiones.php?id=2">Producto 2</a>-->


</form>














<?php include('layout/footer.php')?>



