<?php include('layout/header.php')?>

<a href="1P_AI10.php">ir a Página 1</a> <br><br>


<button onclick="saludar()" >SAludar</button>

<?php include('layout/footer.php')?>



